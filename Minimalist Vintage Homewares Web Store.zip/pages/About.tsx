import React from 'react';

const About: React.FC = () => {
  return (
    <div className="bg-stone-50 min-h-screen">
      <div className="relative py-24 bg-stone-900">
        <div className="absolute inset-0 overflow-hidden">
             <img 
                src="https://picsum.photos/id/48/1920/1080"
                alt="Studio background"
                className="w-full h-full object-cover opacity-40"
             />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-serif font-bold text-white sm:text-5xl lg:text-6xl">Our Story</h1>
            <p className="mt-6 text-xl text-stone-300 max-w-3xl mx-auto">
                Celebrating the beauty of the past in the modern home.
            </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="prose prose-stone prose-lg mx-auto">
          <p className="lead text-2xl font-serif text-stone-800 italic mb-8">
            "Vintage is not just about old things. It's about preserving stories, craftsmanship, and a slower way of living."
          </p>
          <p className="mb-6 text-stone-600">
            Founded in 2024, Lumière Vintage was born from a passion for hunting down the extraordinary. We spend our days scouring estate sales, hidden markets, and auctions across Europe to bring you a carefully curated selection of furniture, lighting, and objects.
          </p>
          <p className="mb-6 text-stone-600">
            We specialize in Mid-Century Modern, Art Deco, and Brutalist design. However, we are not bound by strict definitions. If a piece has character, quality construction, and a certain <em>je ne sais quoi</em>, it belongs in our collection.
          </p>
          <h3 className="text-2xl font-serif text-stone-900 mt-12 mb-4">Sustainability</h3>
          <p className="text-stone-600">
            Choosing vintage is one of the most sustainable ways to furnish your home. By giving existing objects a second life, we reduce waste and bypass the carbon-intensive manufacturing of fast furniture. Every scratch and patina mark is a badge of honor—a sign that this item has been lived with and loved.
          </p>
          <div className="mt-12 p-8 bg-white border border-stone-200">
            <h4 className="text-xl font-serif text-stone-900 mb-2">Visit our Studio</h4>
            <p className="text-stone-500 mb-4">By appointment only.</p>
            <address className="not-italic text-stone-600">
              123 Heritage Lane<br />
              London, UK<br />
              E1 6AN
            </address>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
