import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import TikTokFeed from '../components/TikTokFeed';
import { MOCK_PRODUCTS } from '../constants';

const Home: React.FC = () => {
  const featuredProducts = MOCK_PRODUCTS.slice(0, 4);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <div className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://picsum.photos/id/24/1920/1080" 
            alt="Vintage living room" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-stone-900/30" />
        </div>
        <div className="relative text-center px-4 max-w-4xl mx-auto">
          <span className="text-stone-100 tracking-[0.2em] text-sm uppercase mb-4 block animate-fade-in">Est. 2024</span>
          <h1 className="text-5xl md:text-7xl font-serif text-white mb-6 leading-tight">
            Curated pieces for <br/> soulful living.
          </h1>
          <p className="text-stone-200 text-lg md:text-xl font-light mb-10 max-w-2xl mx-auto">
            Discover a collection of timeless vintage homewares, hand-picked to bring character and history to your space.
          </p>
          <Link 
            to="/shop" 
            className="inline-flex items-center px-8 py-4 bg-white text-stone-900 text-sm tracking-wide font-medium hover:bg-stone-100 transition-colors"
          >
            EXPLORE COLLECTION
          </Link>
        </div>
      </div>

      {/* Intro Text */}
      <section className="py-20 px-4 md:px-8 bg-stone-50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-serif text-stone-900 mb-6">Embrace the Imperfect</h2>
          <p className="text-stone-600 leading-relaxed text-lg">
            We believe that every object has a soul. Our collection focuses on natural materials, 
            patina, and craftsmanship that stands the test of time. From mid-century teak to 
            art deco brass, find the piece that speaks to you.
          </p>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 px-4 md:px-8 max-w-7xl mx-auto w-full">
        <div className="flex justify-between items-end mb-10">
          <h2 className="text-2xl font-serif text-stone-900">Latest Arrivals</h2>
          <Link to="/shop" className="group flex items-center text-sm font-medium text-stone-600 hover:text-stone-900">
            View All <ArrowRight size={16} className="ml-2 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-y-10 gap-x-6 lg:gap-x-8">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* TikTok Section */}
      <TikTokFeed />

    </div>
  );
};

export default Home;
