import React from 'react';
import ProductCard from '../components/ProductCard';
import { MOCK_PRODUCTS } from '../constants';

const Shop: React.FC = () => {
  return (
    <div className="bg-stone-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div>
            <h1 className="text-4xl font-serif text-stone-900">The Collection</h1>
            <p className="mt-4 text-stone-500 max-w-xl">
              A continuously updated selection of vintage furniture, lighting, and decor. 
              Each piece is one-of-a-kind.
            </p>
          </div>
          {/* Simple Filter Placeholder */}
          <div className="mt-6 md:mt-0">
            <span className="text-sm text-stone-500 mr-2">Showing {MOCK_PRODUCTS.length} items</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-12 gap-x-8">
          {MOCK_PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Shop;
