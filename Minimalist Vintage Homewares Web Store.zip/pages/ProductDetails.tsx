import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Check, AlertCircle } from 'lucide-react';
import { MOCK_PRODUCTS } from '../constants';
import { Product } from '../types';

interface ProductDetailsProps {
  onAddToCart: (product: Product) => void;
}

const ProductDetails: React.FC<ProductDetailsProps> = ({ onAddToCart }) => {
  const { id } = useParams<{ id: string }>();
  const product = MOCK_PRODUCTS.find((p) => p.id === id);
  const [added, setAdded] = React.useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-serif text-stone-900 mb-4">Item not found</h2>
        <Link to="/shop" className="text-stone-500 hover:text-stone-900 underline">Back to Shop</Link>
      </div>
    );
  }

  const handleAdd = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="bg-stone-50 min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <Link to="/shop" className="inline-flex items-center text-sm text-stone-500 hover:text-stone-900 mb-8">
          <ArrowLeft size={16} className="mr-2" /> Back to Collection
        </Link>
        
        <div className="lg:grid lg:grid-cols-2 lg:gap-x-16 lg:items-start">
          {/* Image */}
          <div className="aspect-square w-full rounded-sm overflow-hidden bg-stone-200">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
          </div>

          {/* Info */}
          <div className="mt-10 px-4 sm:px-0 sm:mt-16 lg:mt-0">
            <h1 className="text-3xl font-serif font-medium text-stone-900 tracking-tight">{product.name}</h1>
            <div className="mt-3">
              <p className="text-2xl text-stone-900">£{product.price}</p>
            </div>

            <div className="mt-6">
              <h3 className="sr-only">Description</h3>
              <p className="text-base text-stone-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            <div className="mt-8 border-t border-stone-200 pt-8">
              <h3 className="text-sm font-medium text-stone-900">Details</h3>
              <ul className="mt-4 space-y-2">
                {product.details.map((detail, index) => (
                  <li key={index} className="text-sm text-stone-500 flex items-start">
                    <span className="mr-2 text-stone-400">•</span>
                    {detail}
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 border-t border-stone-200 pt-8 flex flex-col space-y-4">
              <div className="flex items-center space-x-2 text-sm text-stone-500">
                <AlertCircle size={16} />
                <span>One in stock - ready to ship.</span>
              </div>
              
              <button
                type="button"
                onClick={handleAdd}
                className={`w-full flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium transition-all duration-200
                  ${added 
                    ? 'bg-green-600 hover:bg-green-700 text-white' 
                    : 'bg-stone-900 hover:bg-stone-800 text-white'
                  }`}
              >
                {added ? (
                  <>
                    <Check size={20} className="mr-2" /> Added to Cart
                  </>
                ) : (
                  'Add to Cart'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
