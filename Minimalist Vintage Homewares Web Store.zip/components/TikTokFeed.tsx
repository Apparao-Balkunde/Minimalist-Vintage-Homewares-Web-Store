import React from 'react';
import { Play } from 'lucide-react';
import { MOCK_TIKTOKS } from '../constants';

const TikTokFeed: React.FC = () => {
  return (
    <section className="bg-white py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif text-stone-900">As Seen On TikTok</h2>
          <p className="mt-4 text-stone-500">Follow us @LumiereVintage for styling tips and new drops.</p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {MOCK_TIKTOKS.map((video) => (
            <div key={video.id} className="relative group cursor-pointer overflow-hidden rounded-lg aspect-[9/16] bg-stone-100">
              <img 
                src={video.thumbnail} 
                alt={video.caption} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center transform scale-90 opacity-80 group-hover:scale-100 group-hover:opacity-100 transition-all">
                  <Play size={20} className="fill-stone-900 stroke-stone-900 ml-1" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                <p className="text-white text-xs font-medium truncate">{video.caption}</p>
                <p className="text-white/80 text-xs mt-1">{video.views} views</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-10 text-center">
          <a href="#" className="inline-flex items-center justify-center px-6 py-3 border border-stone-300 text-sm font-medium text-stone-700 hover:bg-stone-50 transition-colors">
            Follow on TikTok
          </a>
        </div>
      </div>
    </section>
  );
};

export default TikTokFeed;
