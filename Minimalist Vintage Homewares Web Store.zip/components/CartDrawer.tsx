import React from 'react';
import { X, Minus, Plus, Trash2 } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, items, onUpdateQuantity, onRemove }) => {
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] overflow-hidden">
      <div className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm transition-opacity" onClick={onClose} />
      
      <div className="fixed inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md pointer-events-auto bg-stone-50 shadow-xl flex flex-col h-full border-l border-stone-200 transform transition-transform duration-300">
          
          <div className="flex items-center justify-between px-4 py-6 sm:px-6 border-b border-stone-200">
            <h2 className="text-lg font-serif font-medium text-stone-900">Shopping Cart</h2>
            <button onClick={onClose} className="text-stone-400 hover:text-stone-600">
              <X size={24} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-stone-500 space-y-4">
                <p>Your cart is empty.</p>
                <button onClick={onClose} className="text-sm underline underline-offset-4 hover:text-stone-900">
                  Continue Shopping
                </button>
              </div>
            ) : (
              <ul className="space-y-8">
                {items.map((item) => (
                  <li key={item.id} className="flex py-2">
                    <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-sm border border-stone-200">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover object-center"
                      />
                    </div>

                    <div className="ml-4 flex flex-1 flex-col">
                      <div>
                        <div className="flex justify-between text-base font-medium text-stone-900">
                          <h3>{item.name}</h3>
                          <p className="ml-4">£{item.price * item.quantity}</p>
                        </div>
                        <p className="mt-1 text-sm text-stone-500">{item.category}</p>
                      </div>
                      <div className="flex flex-1 items-end justify-between text-sm">
                        <div className="flex items-center border border-stone-300 rounded-sm">
                            <button 
                                onClick={() => onUpdateQuantity(item.id, -1)}
                                className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-50"
                                disabled={item.quantity <= 1}
                            >
                                <Minus size={14} />
                            </button>
                            <span className="px-2 text-stone-900 min-w-[1.5rem] text-center">{item.quantity}</span>
                            <button 
                                onClick={() => onUpdateQuantity(item.id, 1)}
                                className="p-1 text-stone-500 hover:text-stone-900"
                            >
                                <Plus size={14} />
                            </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => onRemove(item.id)}
                          className="font-medium text-red-400 hover:text-red-500 flex items-center gap-1"
                        >
                          <Trash2 size={16} />
                          <span className="sr-only">Remove</span>
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {items.length > 0 && (
            <div className="border-t border-stone-200 px-4 py-6 sm:px-6 bg-white">
              <div className="flex justify-between text-base font-medium text-stone-900 mb-4">
                <p>Subtotal</p>
                <p>£{total}</p>
              </div>
              <p className="mt-0.5 text-sm text-stone-500 mb-6">
                Shipping and taxes calculated at checkout.
              </p>
              <div className="mt-6">
                <button
                  className="w-full flex items-center justify-center bg-stone-900 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-stone-800 transition-colors"
                >
                  Checkout
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
