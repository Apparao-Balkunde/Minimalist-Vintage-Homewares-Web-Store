import React from 'react';
import { Instagram, Facebook, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-100 border-t border-stone-200 mt-auto">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <h3 className="text-lg font-serif font-semibold text-stone-900">Lumière Vintage</h3>
            <p className="text-stone-500 text-sm max-w-xs">
              Curating timeless homewares for the modern sanctuary. Each piece tells a story.
            </p>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-stone-900 tracking-wider uppercase">Support</h4>
            <ul className="space-y-2 text-sm text-stone-500">
              <li><a href="#" className="hover:text-stone-900">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-stone-900">Care Guide</a></li>
              <li><a href="#" className="hover:text-stone-900">FAQ</a></li>
              <li><a href="#" className="hover:text-stone-900">Contact Us</a></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold text-stone-900 tracking-wider uppercase">Follow Us</h4>
            <div className="flex space-x-6">
              <a href="#" className="text-stone-400 hover:text-stone-600">
                <span className="sr-only">Instagram</span>
                <Instagram size={20} />
              </a>
              <a href="#" className="text-stone-400 hover:text-stone-600">
                <span className="sr-only">Facebook</span>
                <Facebook size={20} />
              </a>
              <a href="#" className="text-stone-400 hover:text-stone-600">
                <span className="sr-only">Twitter</span>
                <Twitter size={20} />
              </a>
            </div>
            <p className="text-stone-400 text-xs pt-4">
              &copy; {new Date().getFullYear()} Lumière Vintage. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
