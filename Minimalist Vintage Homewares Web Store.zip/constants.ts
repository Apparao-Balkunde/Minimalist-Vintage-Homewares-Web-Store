import { Product, TikTokVideo } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: '1960s Teak Sideboard',
    price: 1250,
    category: 'Furniture',
    description: 'A stunning mid-century modern teak sideboard featuring organic curves and ample storage.',
    details: ['Width: 180cm', 'Height: 75cm', 'Depth: 45cm', 'Material: Solid Teak'],
    image: 'https://picsum.photos/id/1011/800/800'
  },
  {
    id: '2',
    name: 'Bauhaus Chrome Lamp',
    price: 340,
    category: 'Lighting',
    description: 'Minimalist chrome table lamp inspired by the Bauhaus movement. Perfect for a study or bedside.',
    details: ['Height: 40cm', 'Bulb: E27', 'Material: Chrome Plated Steel'],
    image: 'https://picsum.photos/id/1012/800/800'
  },
  {
    id: '3',
    name: 'Ceramic Stoneware Vase',
    price: 85,
    category: 'Decor',
    description: 'Hand-thrown stoneware vase with a speckled glaze finish. Earthy and grounded.',
    details: ['Height: 25cm', 'Handmade in Japan', 'Watertight'],
    image: 'https://picsum.photos/id/1013/800/800'
  },
  {
    id: '4',
    name: 'Velvet Armchair',
    price: 650,
    category: 'Furniture',
    description: 'Vintage emerald green velvet armchair with brass legs. A statement piece.',
    details: ['Height: 90cm', 'Width: 80cm', 'Material: Cotton Velvet'],
    image: 'https://picsum.photos/id/1025/800/800'
  },
  {
    id: '5',
    name: 'Art Deco Mirror',
    price: 220,
    category: 'Decor',
    description: 'Geometric frameless mirror from the 1930s. Adds light and space to any hallway.',
    details: ['Dimensions: 60x80cm', 'Original backing', 'Beveled edges'],
    image: 'https://picsum.photos/id/1042/800/800'
  },
  {
    id: '6',
    name: 'Woven Rattan Basket',
    price: 45,
    category: 'Storage',
    description: 'Large vintage rattan basket, originally used for grain storage. Ideal for blankets.',
    details: ['Diameter: 50cm', 'Height: 45cm', 'Natural fibers'],
    image: 'https://picsum.photos/id/1056/800/800'
  },
  {
    id: '7',
    name: 'Brass Candle Holders',
    price: 60,
    category: 'Decor',
    description: 'Set of two heavy solid brass candle holders. Patina consistent with age.',
    details: ['Height: 15cm', 'Fits standard taper candles', 'Solid Brass'],
    image: 'https://picsum.photos/id/1059/800/800'
  },
  {
    id: '8',
    name: 'Marble Coffee Table',
    price: 890,
    category: 'Furniture',
    description: 'Italian Carrara marble coffee table with a sleek iron base.',
    details: ['Diameter: 90cm', 'Height: 35cm', 'Weight: 40kg'],
    image: 'https://picsum.photos/id/1060/800/800'
  }
];

export const MOCK_TIKTOKS: TikTokVideo[] = [
  { id: 't1', thumbnail: 'https://picsum.photos/id/201/300/533', views: '12.5k', caption: 'Styling the new teak sideboard ✨ #vintage #homedecor' },
  { id: 't2', thumbnail: 'https://picsum.photos/id/202/300/533', views: '8.2k', caption: 'Sunday market haul! Look at these lamps 💡 #thrifting' },
  { id: 't3', thumbnail: 'https://picsum.photos/id/203/300/533', views: '45k', caption: 'How to clean vintage brass properly 🧼 #restoration' },
  { id: 't4', thumbnail: 'https://picsum.photos/id/204/300/533', views: '3.1k', caption: 'Packing orders with me 📦 #smallbusiness' },
];
