import { GoogleGenAI } from "@google/genai";
import { Product, ChatMessage } from "../types";

const SYSTEM_INSTRUCTION = `
You are the "Digital Curator" for Lumière Vintage, a high-end online store selling curated vintage homewares.
Your tone is sophisticated, knowledgeable (especially about design history like Mid-century Modern, Bauhaus, Art Deco), yet warm and approachable.
You help customers find products from our inventory, answer questions about item care, and suggest styling tips.

Here is the current product inventory (in JSON format):
{{INVENTORY}}

Rules:
1. Always reference the specific products available in the inventory if they match the user's request.
2. If the user asks about something we don't have, politely explain we curate specific vintage pieces and suggest the closest alternative from our list.
3. Keep responses concise (under 100 words) unless asked for a detailed history.
4. Do not make up products that are not in the inventory list.
5. If asked about shipping, say we ship worldwide with bespoke packaging.
`;

export const getCuratorResponse = async (
  history: ChatMessage[],
  currentMessage: string,
  products: Product[]
): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      return "I'm sorry, I seem to be disconnected from my knowledge base (API Key missing).";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Inject inventory into system instruction
    const inventoryString = JSON.stringify(products.map(p => ({
      name: p.name,
      price: p.price,
      category: p.category,
      description: p.description
    })));
    
    const finalSystemInstruction = SYSTEM_INSTRUCTION.replace('{{INVENTORY}}', inventoryString);

    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: finalSystemInstruction,
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }],
      })),
    });

    const result = await chat.sendMessage({ message: currentMessage });
    return result.text || "I'm having a moment of silence. Could you repeat that?";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I apologize, I'm having trouble accessing the archives right now. Please try again later.";
  }
};
